
import log.soma;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author CC-Student
 */
public class login implements soma {
    String months;
    String days;
    String years;
      public void speedup(int a , String c){
             days+=a;
          months+=c;
          System.out.println("month = "+"ramadan");
            a=30;
          System.out.println("days of years =" +a+"days");
          
      }
    public void speedDwon(int a , String b){
                years+=b;

        System.out.println("years tow Eid ramadan and qorban");
          b=" eid ramadan ";
        
    }
    public void changeGear(int a){
        System.out.println("days of Eid "+a+"day");
               a=3;

    }

    @Override
    public void speedup(int a) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void speedDwon(int a) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
