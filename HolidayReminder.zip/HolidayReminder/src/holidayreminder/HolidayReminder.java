/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package holidayreminder;

import javax.swing.JOptionPane;


public class HolidayReminder {

   private String days;
   private String months;
   private String date;
   
   public void setmonth(String a) {
       String months=a;
   } public String getmonth(){
       return months;
   }
}
class christmas extends HolidayReminder{
    protected String startday ="25/December";
    protected String Edndays="2/january";
    protected String startDay="11/march";
    protected String EndDay="24/march";
    protected String day="9/november";
   
     public static void main(String[] args) {
        
        HolidayReminder obj = new HolidayReminder();
              christmas a=new christmas();

      obj.setmonth("march");
     
       
         System.out.println("the march of  started:"+"{"+a.startDay+"}"+"\n EndDay "+"{"+a.EndDay+"}");
         System.out.println("the day of maulud pexambar :  "+"{"+a.day+"}");
         System.out.println("the christmas satrt day :"+"{"+a.startday+"}");
         System.out.println("the christmas end day: "+"{"+a.Edndays+"}");
    }
    
}