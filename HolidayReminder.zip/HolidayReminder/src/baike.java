
import log.soma;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author CC-Student
 */
public class baike implements soma {
    String months;
    String days;
    String years;
    
      public void speedup(int a , String c){
          days+=a;
          months+=c;
          System.out.println("month"+"ramadan");
        a=30;
          System.out.println("days of manth "+a);
      }
    public void speedDwon(int a , String b){
        years+=b;
        System.out.println("years"+"two Eid ramadan and qorban ");
        
        
        
    }
    public void changeGear(int a){
        
        System.out.println("days of Eid "+a);
       a=3;
    }
public void print(){
    System.out.println("months is"+months+"days is"+days+"years is"+years);
}
        
    @Override
    public void speedup(int a) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void speedDwon(int a) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
