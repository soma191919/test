/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package log;

/**
 *
 * @author CC-Student
 */
 public interface soma {
    public void speedup(int a);
    public void speedDwon(int a);
    public void changeGear(int a);
}