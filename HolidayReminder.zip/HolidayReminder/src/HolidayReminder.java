/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author CC-Student
 */
public class HolidayReminder {
         public static void main(String[] args) {

  login ob =new login();
  ob.changeGear(3);
  ob.speedDwon(1, "ramadan eid");
  ob.speedup(30,"days of years");
  
}
}